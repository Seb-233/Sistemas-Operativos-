#ifndef HILO_AUX2_H
#define HILO_AUX2_H

void *hiloAuxiliar2(void *arg);
void generarReporte();

#endif
