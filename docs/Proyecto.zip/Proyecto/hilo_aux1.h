#ifndef HILO_AUX1_H
#define HILO_AUX1_H

void *hiloAuxiliar1(void *arg);

#endif

